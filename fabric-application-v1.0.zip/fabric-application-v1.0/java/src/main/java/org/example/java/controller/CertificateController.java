package org.example.java.controller;

import net.sf.json.JSONObject;
import org.example.java.chaincode.invocation.QueryChaincode;
import org.example.java.client.CAClient;
import org.example.java.client.ChannelClient;
import org.example.java.client.FabricClient;
import org.example.java.config.Config;
import org.example.java.entity.applicationrecord;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.example.java.util.Crypto.AESCrypto.decode;
import static org.example.java.util.Crypto.RSACrypto.*;

public class CertificateController {
    private final String str_cer="Do you have permission";


    //
    /*
    * 查询用户名的密钥
    * 并使用它来签名和验证签名
    *
    * */
    //进行签名和验签
    @RequestMapping("/RSAsign")
    @ResponseBody
    public String RSAsign(@RequestParam(name="dataset") String Dataset,
                       @RequestParam(name="applicant")String Applicant) {
        String Sign_return = "加密失败";
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();
            String[] args1 = {Dataset};
            //String[] args2 = {Dataset};
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord - " + args1[0]);

            Collection<ProposalResponse> responses1Query = channelClient.queryByChainCode("odschaincode", "readApplicationRecord", args1);
            for (ProposalResponse pres : responses1Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());

                //调出查询结果

                if (!Applicant.equals(JSONObject.fromObject(stringResponse).getString("applicant"))) {
                    return "error";
                } else {
                    String OriginKey = JSONObject.fromObject(stringResponse).getString("cryptokey");
                    String AES_key = "aaaaaaaaaabbbbbbaaaaaaaaaabbbbbb";
                    String CryptoKey = decode(AES_key, OriginKey);

                    String[] CryptoKeyArr = CryptoKey.split("\\s+");
                    String PublicKey = CryptoKeyArr[0];//仅在签名和验签中起作用
                    String EncData = CryptoKeyArr[1];
                    String PriKey = CryptoKeyArr[2];

                    //RSA签名
                    String sign = sign(EncData, getPrivateKey(PriKey));
                    System.out.println("签名:"+sign);


                    // RSA验签
                    boolean result = verify(EncData, getPublicKey(PublicKey), sign);
                    System.out.print("验签结果:" + result);

                    //签名和验签结果
                    Sign_return = sign;

                }
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return Sign_return;
    }




    @RequestMapping("/Rsacertificate")
    @ResponseBody
    public  String Rsacertificate(){

        return "";
    }


}
