package org.example.java.controller;

import org.example.java.client.CAClient;
import org.example.java.config.Config;
import org.example.java.user.RegisterEnrollUser;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/*
 * @author:likaiyuan
 *
 *
 * */


@Controller
public class RegisterEnrollController {

    String str_register_enroll="用户注册失败";

    /*
    *
    *
    * 通过CA和MSP注册用户
    *
    * */

    @RequestMapping("/registerenroll")
    @ResponseBody
    public String registerenroll(){
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            // Register and Enroll user to Org1MSP
            UserContext userContext = new UserContext();
            String name = "user"+System.currentTimeMillis();
            userContext.setName(name);
            userContext.setAffiliation(Config.ORG1);
            userContext.setMspId(Config.ORG1_MSP);
            str_register_enroll="用户注册成功"+"\n";
            String eSecret = caClient.registerUser(name, Config.ORG1);

            userContext = caClient.enrollUser(userContext, eSecret);
            str_register_enroll+=""+adminUserContext+"\n";
            str_register_enroll+=""+eSecret.toString()+"\n";
            str_register_enroll+=""+userContext+"\n";

        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!str_register_enroll.toString().equals("注册失败")){
            return str_register_enroll;
        }else{
            return "用户注册失败";
        }

    }

    @RequestMapping("/registerenrollbyid")
    @ResponseBody
    public String registerenrollbyid(){
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            // Register and Enroll user to Org1MSP
            UserContext userContext = new UserContext();
            String name = "user"+System.currentTimeMillis();
            userContext.setName(name);
            userContext.setAffiliation(Config.ORG1);
            userContext.setMspId(Config.ORG1_MSP);
            str_register_enroll="用户注册成功"+"\n";
            String eSecret = caClient.registerUser(name, Config.ORG1);

            userContext = caClient.enrollUser(userContext, eSecret);
            str_register_enroll+=""+adminUserContext+"\n";
            str_register_enroll+=""+eSecret.toString()+"\n";
            str_register_enroll+=""+userContext+"\n";

        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!str_register_enroll.toString().equals("注册失败")){
            return str_register_enroll;
        }else{
            return "用户注册失败";
        }

    }
}
