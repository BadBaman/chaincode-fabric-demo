package org.example.java.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 * @author:likaiyuan
 *
 *
 * */


@Controller
public class BaseController {
    @RequestMapping("/")
    public String index(){
        return "index";
    }



    /*
    * 后台管理页面映射
    * */

    @RequestMapping("/page/welcome-1.html")
    public String welcome(){
        return "/page/welcome-1";
    }


    @RequestMapping("/page/table.html")
    public String table(){
        return "/page/table";
    }

    @RequestMapping("/page/table/add.html")
    public String tableadd(){
        return "/page/table/add";
    }
    @RequestMapping("/page/table/edit.html")
    public String tableedit(){
        return "edit1";
    }

    @RequestMapping("/page/form.html")
    public String layuiform(){
        return "/page/form";
    }

    @RequestMapping("/page/form-step.html")
    public String layuiformstep(){
        return "/page/form-step";
    }
    @RequestMapping("/page/menu.html")
    public String layuimenu(){
        return "/page/menu";
    }

    @RequestMapping("/page/404.html")
    public String layui404(){
        return "/page/404";
    }
    @RequestMapping("/page/icon.html")
    public String layuiicon(){
        return "/page/icon";
    }

    @RequestMapping("/page/icon-picker.html")
    public String layuiiconpicker(){
        return "/page/icon-picker";
    }

    @RequestMapping("/page/setting.html")
    public String layuisetting(){
        return "/page/setting";
    }


    @RequestMapping("/applicationrecord")
    public String applicationrecord(){
        return "applicationrecord";
    }

    @RequestMapping("/form")
    public String form(){
        return "form";
    }

    @RequestMapping("/home")
    public String home(){
        return "home";
    }


    @RequestMapping("/applicationtable")
    public String applicationtable(){
        return "applicationtable";
    }
}
