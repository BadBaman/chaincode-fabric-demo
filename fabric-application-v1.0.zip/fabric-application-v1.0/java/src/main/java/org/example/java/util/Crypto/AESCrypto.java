package org.example.java.util.Crypto;

import org.apache.commons.codec.binary.Hex;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class AESCrypto {
    public static void main(String[] args) throws UnsupportedEncodingException {
        for (int i = 0; i < 10; i++) {
            String key = generateKey(); // 提前生成的一个key
            System.out.println("密钥: " + key);
            String ps = encode(key, "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAJvVKspH/3YChFaHDyj0L9RJIvPPm4qDVJm3htc/Nt6Gb1GqMKWhDEpRKC7RhqNCr5pp9mJGrMpypz80jGWq9lP5WpM3cMmkUN7G8ZguAzcYhG4qrztfQL6WlzTg9ENXfMao9tFPhxEHxSUw+e5TPRx9ze+43x503xkx48gLnPi7AgMBAAECgYAVyaEY9SYPjtyH6IxDEpkZWjxr0EwT+ra6Y0GUGL+IL02jImN41OKOBXjTyvHDI9C/iy8qoG0KRSuDF8rFcDjOXjrfV37WELzF4sXKawBGYYSjA8qAUeIvxJ20kve8KvFQ23/aV4eVwpx2UW/FYNe4T2hlSWuIPKTp83T4lto4uQJBAOxTpYhoCFUb4JfHcEMAgp2bgYprdSV2tD8/aST3NK7xkuH4hgSzKXnNETELBEUvb4RDu4we7vVLeOFaLtPDjdcCQQCozh0VwkdXkKtjKssOcfH6efAbPEF6u2Hn4h0gz0pQ4yh3p/8mOv1B28dImUKaRhRCd6lFHjxmpr9YBvUAOqe9AkEArGrijECKQ73RACtLpjaLFP3NZvW7RBf0rWhQB94rm6834JF3BZrJGcoZTtSgyvEuxSq9fB9da60ihhdLrsgvhQJAKUf2juqq/bwQXbkKXWb6MTH+yPpMXRJUGBwQ2YQ3/V3/+HsqB5RneOKhcpygUBARRkvzJkcFqGjg5EsXQU4W1QJBAKd7qkBWdJssprk0hsF5yufpc8zKnLSjiXfOV6U6AfmSyCjOpT+DDCMCPfuAxtigutWb5pZfBmmleDADcjJ1wfQ=");
            System.out.println("加密: " + ps);
            String res = decode(key, ps);
            //String res1 = decode(key,"741c00809e242a0d0571a84160176cb6");
            System.out.println("解密: " + res);

            //第二次
            String key1 = generateKey(); // 提前生成的一个key
            System.out.println("密钥: " + key1);
            String ps1 = encode(key1, "\"MIICdwIBADANBgkqhkiG 9w0BAQEFAASCAmEwggJdAgEAAoGBAJvVKspH/3YChFaHDyj0L9RJIvPPm4qDVJm3htc/Nt6Gb1GqMKWhDEpRKC7RhqNCr5pp9mJGrMpypz80jGWq9lP5WpM3cMmkUN7G8ZguAzcYhG4qrztfQL6WlzTg9ENXfMao9tFPhxEHxSUw+e5TPRx9ze+43x503xkx48gLnPi7AgMBAAECgYAVyaEY9SYPjtyH6IxDEpkZWjxr0EwT+ra6Y0GUGL+IL02jImN41OKOBXjTyvHDI9C/iy8qoG0KRSuDF8rFcDjOXjrfV37WELzF4sXKawBGYYSjA8qAUeIvxJ20kve8KvFQ23/aV4eVwpx2UW/FYNe4T2hlSWuIPKTp83T4lto4uQJBAOxTpYhoCFUb4JfHcEMAgp2bgYprdSV2tD8/aST3NK7xkuH4hgSzKXnNETELBEUvb4RDu4we7vVLeOFaLtPDjdcCQQCozh0VwkdXkKtjKssOcfH6efAbPEF6u2Hn4h0gz0pQ4yh3p/8mOv1B28dImUKaRhRCd6lFHjxmpr9YBvUAOqe9AkEArGrijECKQ73RACtLpjaLFP3NZvW7RBf0rWhQB94rm6834JF3BZrJGcoZTtSgyvEuxSq9fB9da60ihhdLrsgvhQJAKUf2juqq/bwQXbkKXWb6MTH+yPpMXRJUGBwQ2YQ3/V3/+HsqB5RneOKhcpygUBARRkvzJkcFqGjg5EsXQU4W1QJBAKd7qkBWdJssprk0hsF5yufpc8zKnLSjiXfOV6U6AfmSyCjOpT+DDCMCPfuAxtigutWb5pZfBmmleDADcjJ1wfQ=\n");
            System.out.println("加密: " + ps1);
            String key2 = "aaaaaaaaaabbbbbbaaaaaaaaaabbbbbb"; // 提前生成的一个key
            String ps2 = encode(key2, ps1);
            System.out.println("加密第二次: "+ps2);
            String res2 = decode(key2, ps2);
            System.out.println("解密第二次: "+res2);
            String res1 = decode(key1, ps1);
            //String res1 = decode(key,"741c00809e242a0d0571a84160176cb6");
            System.out.println("解密: " + res1);

            //第三次

            String key_1 = generateKey(); // 提前生成的一个key
            System.out.println("密钥: " + key_1);
            String ps_1 = encode(key_1, "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAJvVKspH/3YChFaHDyj0L9RJIvPPm4qDVJm3htc/Nt6Gb1GqMKWhDEpRKC7RhqNCr5pp9mJGrMpypz80jGWq9lP5WpM3cMmkUN7G8ZguAzcYhG4qrztfQL6WlzTg9ENXfMao9tFPhxEHxSUw+e5TPRx9ze+43x503xkx48gLnPi7AgMBAAECgYAVyaEY9SYPjtyH6IxDEpkZWjxr0EwT+ra6Y0GUGL+IL02jImN41OKOBXjTyvHDI9C/iy8qoG0KRSuDF8rFcDjOXjrfV37WELzF4sXKawBGYYSjA8qAUeIvxJ20kve8KvFQ23/aV4eVwpx2UW/FYNe4T2hlSWuIPKTp83T4lto4uQJBAOxTpYhoCFUb4JfHcEMAgp2bgYprdSV2tD8/aST3NK7xkuH4hgSzKXnNETELBEUvb4RDu4we7vVLeOFaLtPDjdcCQQCozh0VwkdXkKtjKssOcfH6efAbPEF6u2Hn4h0gz0pQ4yh3p/8mOv1B28dImUKaRhRCd6lFHjxmpr9YBvUAOqe9AkEArGrijECKQ73RACtLpjaLFP3NZvW7RBf0rWhQB94rm6834JF3BZrJGcoZTtSgyvEuxSq9fB9da60ihhdLrsgvhQJAKUf2juqq/bwQXbkKXWb6MTH+yPpMXRJUGBwQ2YQ3/V3/+HsqB5RneOKhcpygUBARRkvzJkcFqGjg5EsXQU4W1QJBAKd7qkBWdJssprk0hsF5yufpc8zKnLSjiXfOV6U6AfmSyCjOpT+DDCMCPfuAxtigutWb5pZfBmmleDADcjJ1wfQ=");
            String ps_2 = encode(key_1, "MIIC dwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAJvVKspH/3YChFaHDyj0L9RJIvPPm4qDVJm3htc/Nt6Gb1GqMKWhDEpRKC7RhqNCr5pp9mJGrMpypz80jGWq9lP5WpM3cMmkUN7G8ZguAzcYhG4qrztfQL6WlzTg9ENXfMao9tFPhxEHxSUw+e5TPRx9ze+43x503xkx48gLnPi7AgMBAAECgYAVyaEY9SYPjtyH6IxDEpkZWjxr0EwT+ra6Y0GUGL+IL02jImN41OKOBXjTyvHDI9C/iy8qoG0KRSuDF8rFcDjOXjrfV37WELzF4sXKawBGYYSjA8qAUeIvxJ20kve8KvFQ23/aV4eVwpx2UW/FYNe4T2hlSWuIPKTp83T4lto4uQJBAOxTpYhoCFUb4JfHcEMAgp2bgYprdSV2tD8/aST3NK7xkuH4hgSzKXnNETELBEUvb4RDu4we7vVLeOFaLtPDjdcCQQCozh0VwkdXkKtjKssOcfH6efAbPEF6u2Hn4h0gz0pQ4yh3p/8mOv1B28dImUKaRhRCd6lFHjxmpr9YBvUAOqe9AkEArGrijECKQ73RACtLpjaLFP3NZvW7RBf0rWhQB94rm6834JF3BZrJGcoZTtSgyvEuxSq9fB9da60ihhdLrsgvhQJAKUf2juqq/bwQXbkKXWb6MTH+yPpMXRJUGBwQ2YQ3/V3/+HsqB5RneOKhcpygUBARRkvzJkcFqGjg5EsXQU4W1QJBAKd7qkBWdJssprk0hsF5yufpc8zKnLSjiXfOV6U6AfmSyCjOpT+DDCMCPfuAxtigutWb5pZfBmmleDADcjJ1wfQ=");

            System.out.println("加密: " + ps_1);
            System.out.println("加密: " + ps_2);
            String res_1 = decode(key_1, ps_1);
            //String res1 = decode(key,"741c00809e242a0d0571a84160176cb6");
            System.out.println("解密: " + res_1);



        }
    }


    /**
     * 生成key
     * @return
     */
    public static String generateKey() {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(new SecureRandom());
            SecretKey secretKey = keyGenerator.generateKey();
            byte[] byteKey = secretKey.getEncoded();
            return Hex.encodeHexString(byteKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * AES加密
     * @param thisKey
     * @param data
     * @return
     */
    public static String encode(String thisKey, String data) {
        try {
            // 转换KEY
            Key key = new SecretKeySpec(Hex.decodeHex(thisKey),"AES");
            //System.out.println(thisKey);

            // 加密
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] result = cipher.doFinal(data.getBytes());
            return Hex.encodeHexString(result);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * AES解密
     * @param thisKey
     * @param data
     * @return
     */
    public static String decode(String thisKey, String data) {
        try {
            // 转换KEY
            Key key = new SecretKeySpec(Hex.decodeHex(thisKey),"AES");
            // 解密
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] result = cipher.doFinal(Hex.decodeHex(data));
            return new String(result);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}