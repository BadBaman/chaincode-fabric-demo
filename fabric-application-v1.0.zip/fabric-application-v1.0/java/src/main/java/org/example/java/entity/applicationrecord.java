package org.example.java.entity;

import java.util.Objects;

/*
 * @author:likaiyuan
 *
 *
 * */


public class applicationrecord {
    private String dataset;
    private String Applicant;
    private String Noticer;
    private String Noticetime;
    private String Confirmor;
    private String Confirmtime;
    private String Omicsoriginalresultprovider;
    private String Omicsoriginalapplicationreceivedtime;
    private String Omicsanalysisresultprovider;
    private String Omicsapplicationreceivedtime;
    private String Phenotypicdataprovider;
    private String Phenotypicapplicationreceivedtime;
    private String Datadeliverytime;
    private String Datadeliverymethod;
    private String Deliverer;
    private String Deliverercontactinformation;

    public String getDataset() {
        return dataset;
    }

    public void setDataset(String id) {
        this.dataset = id;
    }
    public applicationrecord(){

    }
    public applicationrecord(String dataset,String applicant, String noticer, String noticetime, String confirmor, String confirmtime, String omicsoriginalresultprovider, String omicsoriginalapplicationreceivedtime, String omicsanalysisresultprovider, String omicsapplicationreceivedtime, String phenotypicdataprovider, String phenotypicapplicationreceivedtime, String datadeliverytime, String datadeliverymethod, String deliverer, String deliverercontactinformation) {
        this.dataset=dataset;
        this.Applicant = applicant;
        this.Noticer = noticer;
        this.Noticetime = noticetime;
        this.Confirmor = confirmor;
        this.Confirmtime = confirmtime;
        this.Omicsoriginalresultprovider = omicsoriginalresultprovider;
        this.Omicsoriginalapplicationreceivedtime = omicsoriginalapplicationreceivedtime;
        this.Omicsanalysisresultprovider = omicsanalysisresultprovider;
        this.Omicsapplicationreceivedtime = omicsapplicationreceivedtime;
        this.Phenotypicdataprovider = phenotypicdataprovider;
        this.Phenotypicapplicationreceivedtime = phenotypicapplicationreceivedtime;
        this.Datadeliverytime = datadeliverytime;
        this.Datadeliverymethod = datadeliverymethod;
        this.Deliverer = deliverer;
        this.Deliverercontactinformation = deliverercontactinformation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        applicationrecord that = (applicationrecord) o;
        return Objects.equals(dataset, that.dataset) &&
                Objects.equals(Applicant, that.Applicant) &&
                Objects.equals(Noticer, that.Noticer) &&
                Objects.equals(Noticetime, that.Noticetime) &&
                Objects.equals(Confirmor, that.Confirmor) &&
                Objects.equals(Confirmtime, that.Confirmtime) &&
                Objects.equals(Omicsoriginalresultprovider, that.Omicsoriginalresultprovider) &&
                Objects.equals(Omicsoriginalapplicationreceivedtime, that.Omicsoriginalapplicationreceivedtime) &&
                Objects.equals(Omicsanalysisresultprovider, that.Omicsanalysisresultprovider) &&
                Objects.equals(Omicsapplicationreceivedtime, that.Omicsapplicationreceivedtime) &&
                Objects.equals(Phenotypicdataprovider, that.Phenotypicdataprovider) &&
                Objects.equals(Phenotypicapplicationreceivedtime, that.Phenotypicapplicationreceivedtime) &&
                Objects.equals(Datadeliverytime, that.Datadeliverytime) &&
                Objects.equals(Datadeliverymethod, that.Datadeliverymethod) &&
                Objects.equals(Deliverer, that.Deliverer) &&
                Objects.equals(Deliverercontactinformation, that.Deliverercontactinformation);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dataset,Applicant, Noticer, Noticetime, Confirmor, Confirmtime, Omicsoriginalresultprovider, Omicsoriginalapplicationreceivedtime, Omicsanalysisresultprovider, Omicsapplicationreceivedtime, Phenotypicdataprovider, Phenotypicapplicationreceivedtime, Datadeliverytime, Datadeliverymethod, Deliverer, Deliverercontactinformation);
    }

    public String getApplicant() {
        return Applicant;
    }

    public void setApplicant(String applicant) {
        Applicant = applicant;
    }

    public String getNoticer() {
        return Noticer;
    }

    public void setNoticer(String noticer) {
        Noticer = noticer;
    }

    public String getNoticetime() {
        return Noticetime;
    }

    public void setNoticetime(String noticetime) {
        Noticetime = noticetime;
    }

    public String getConfirmor() {
        return Confirmor;
    }

    public void setConfirmor(String confirmor) {
        Confirmor = confirmor;
    }

    public String getConfirmtime() {
        return Confirmtime;
    }

    public void setConfirmtime(String confirmtime) {
        Confirmtime = confirmtime;
    }

    public String getOmicsoriginalresultprovider() {
        return Omicsoriginalresultprovider;
    }

    public void setOmicsoriginalresultprovider(String omicsoriginalresultprovider) {
        Omicsoriginalresultprovider = omicsoriginalresultprovider;
    }

    public String getOmicsoriginalapplicationreceivedtime() {
        return Omicsoriginalapplicationreceivedtime;
    }

    public void setOmicsoriginalapplicationreceivedtime(String omicsoriginalapplicationreceivedtime) {
        Omicsoriginalapplicationreceivedtime = omicsoriginalapplicationreceivedtime;
    }

    public String getOmicsanalysisresultprovider() {
        return Omicsanalysisresultprovider;
    }

    public void setOmicsanalysisresultprovider(String omicsanalysisresultprovider) {
        Omicsanalysisresultprovider = omicsanalysisresultprovider;
    }

    public String getOmicsapplicationreceivedtime() {
        return Omicsapplicationreceivedtime;
    }

    public void setOmicsapplicationreceivedtime(String omicsapplicationreceivedtime) {
        Omicsapplicationreceivedtime = omicsapplicationreceivedtime;
    }

    public String getPhenotypicdataprovider() {
        return Phenotypicdataprovider;
    }

    public void setPhenotypicdataprovider(String phenotypicdataprovider) {
        Phenotypicdataprovider = phenotypicdataprovider;
    }

    public String getPhenotypicapplicationreceivedtime() {
        return Phenotypicapplicationreceivedtime;
    }

    public void setPhenotypicapplicationreceivedtime(String phenotypicapplicationreceivedtime) {
        Phenotypicapplicationreceivedtime = phenotypicapplicationreceivedtime;
    }

    public String getDatadeliverytime() {
        return Datadeliverytime;
    }

    public void setDatadeliverytime(String datadeliverytime) {
        Datadeliverytime = datadeliverytime;
    }

    public String getDatadeliverymethod() {
        return Datadeliverymethod;
    }

    public void setDatadeliverymethod(String datadeliverymethod) {
        Datadeliverymethod = datadeliverymethod;
    }

    public String getDeliverer() {
        return Deliverer;
    }

    public void setDeliverer(String deliverer) {
        Deliverer = deliverer;
    }

    public String getDeliverercontactinformation() {
        return Deliverercontactinformation;
    }

    public void setDeliverercontactinformation(String deliverercontactinformation) {
        Deliverercontactinformation = deliverercontactinformation;
    }
}
