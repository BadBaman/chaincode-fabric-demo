package org.example.java.controller;

import net.sf.json.JSONArray;
import org.example.java.chaincode.invocation.InvokeChaincode;
import org.example.java.chaincode.invocation.QueryChaincode;
import org.example.java.client.CAClient;
import org.example.java.client.ChannelClient;
import org.example.java.client.FabricClient;
import org.example.java.config.Config;
import org.example.java.entity.applicationrecord;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionException;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.nio.charset.StandardCharsets.UTF_8;


/*
 * @author:likaiyuan
 *
 *
 * */



@Controller
public class ChaincodeController {
    private static int NUM_OF_APLLICATION=0;
    private static final byte[] EXPECTED_EVENT_DATA = "!".getBytes(UTF_8);
    private static final String EXPECTED_EVENT_NAME = "event";
    private String str_chaincode_invoke="调用失败";

    /*
    *
    * 账本的部分查询
    * */

    @RequestMapping("/chaincodequery")
    public String chaincodeQuery(){
        return "success";
    }

    @RequestMapping("/queryapplicationrecordbyDataset")
    public ModelAndView queryapplicationrecordbyid(@RequestParam (name="Dataset")String Dataset){
        ModelAndView mv=new ModelAndView();
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();
            String[] args1 = {"Dataset1"};
            String[] args2 = {Dataset};
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord - " + args1[0]);

            Collection<ProposalResponse>  responses1Query = channelClient.queryByChainCode("odschaincode", "readApplicationRecord", args1);
            for (ProposalResponse pres : responses1Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }

            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for all  - " );
            Collection<ProposalResponse>  responses2Query = channelClient.queryByChainCode("odschaincode", "readApplicationRecord",args2);
            for (ProposalResponse pres : responses2Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                mv.addObject("Dataset",JSONObject.fromObject(stringResponse).getString("dataset"));
                mv.addObject("Applicant",JSONObject.fromObject(stringResponse).getString("applicant"));
                mv.addObject("Noticer",JSONObject.fromObject(stringResponse).getString("noticer"));
                mv.addObject("Noticetime",JSONObject.fromObject(stringResponse).getString("noticetime"));
                mv.addObject("Confirmor",JSONObject.fromObject(stringResponse).getString("confirmor"));
                mv.addObject("Confirmtime",JSONObject.fromObject(stringResponse).getString("confirmtime"));
                mv.addObject("Omicsoriginalresultprovider",JSONObject.fromObject(stringResponse).getString("omicsoriginalresultprovider"));
                mv.addObject("Omicsoriginalapplicationreceivedtime",JSONObject.fromObject(stringResponse).getString("omicsoriginalapplicationreceivedtime"));
                mv.addObject("Omicsanalysisresultprovider",JSONObject.fromObject(stringResponse).getString("omicsanalysisresultprovider"));
                mv.addObject("Omicsapplicationreceivedtime",JSONObject.fromObject(stringResponse).getString("omicsapplicationreceivedtime"));
                mv.addObject("Phenotypicdataprovider",JSONObject.fromObject(stringResponse).getString("phenotypicdataprovider"));
                mv.addObject("Phenotypicapplicationreceivedtime",JSONObject.fromObject(stringResponse).getString("phenotypicapplicationreceivedtime"));
                mv.addObject("Datadeliverytime",JSONObject.fromObject(stringResponse).getString("datadeliverytime"));
                mv.addObject("Datadeliverymethod",JSONObject.fromObject(stringResponse).getString("datadeliverymethod"));
                mv.addObject("Deliverer",JSONObject.fromObject(stringResponse).getString("deliverer"));
                mv.addObject("Deliverercontactinformation",JSONObject.fromObject(stringResponse).getString("deliverercontactinformation"));

                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse+"\n");
            }



            mv.setViewName("applicationrecord");

            //str1="区块长度:"+channel.queryBlockchainInfo().getHeight();
            //str2+=channel.queryBlockchainInfo().getCurrentBlockHash();
            //channel.queryBlockByNumber(1);
        } catch (Exception e) {
            e.printStackTrace();
        }

            return mv;
    }


    /*
    *
    * 同时查询账本中所有记录
    *
    * */


    @RequestMapping("/queryallapplicationrecord")
    @ResponseBody
    public List<applicationrecord> queryallapplicationrecord(){
        //ModelAndView mv=new ModelAndView();
        List<applicationrecord> applic=new ArrayList<applicationrecord>();
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);
            String[] args = {"dataset0","dataset50"};
            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for all applicationRecords ...");
            Collection<ProposalResponse>  responsesQuery = channelClient.queryByChainCode("odschaincode", "getApplicationRecordsByRange", args);

            for (ProposalResponse pres : responsesQuery) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                for(int i=0;i<JSONArray.fromObject(stringResponse).size();i++){
                    System.out.println(JSONArray.fromObject(stringResponse).get(i));

                    applicationrecord app =new applicationrecord();
                    JSONObject jsonObject=JSONObject.fromObject(JSONObject.fromObject(JSONArray.fromObject(stringResponse).get(i)).getString("Record"));
                    app.setDataset(JSONObject.fromObject(JSONArray.fromObject(stringResponse).get(i)).getString("Key"));

                    app.setApplicant(jsonObject.getString("applicant"));
                    app.setNoticer(jsonObject.getString("noticer"));
                    app.setNoticetime(jsonObject.getString("noticetime"));
                    app.setConfirmor(jsonObject.getString("confirmor"));
                    app.setConfirmtime(jsonObject.getString("confirmtime"));
//                    app.setOmicsoriginalresultprovider(jsonObject.getString("组学原始数据提供人"));
//                    app.setOmicsoriginalapplicationreceivedtime(jsonObject.getString("组学原始数据申请收到时间"));
//                    app.setOmicsanalysisresultprovider(jsonObject.getString("组学分析数据提供人"));
//                    app.setOmicsapplicationreceivedtime(jsonObject.getString("组学分析数据申请收到时间"));
//                    app.setPhenotypicdataprovider(jsonObject.getString("表型数据提供人"));
//                    app.setPhenotypicapplicationreceivedtime(jsonObject.getString("表型数据申请收到时间"));
//                    app.setDatadeliverytime(jsonObject.getString("数据交付时间"));
//                    app.setDatadeliverymethod(jsonObject.getString("数据交付方式"));
//                    app.setDeliverer(jsonObject.getString("数据交付人"));
//                    app.setDeliverercontactinformation(jsonObject.getString("联系方式"));
                    applic.add(app) ;
                }



                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse+"\n");
            }


            //mv.setViewName("applicationtable");
            //Thread.sleep(10000);



            //str1="区块长度:"+channel.queryBlockchainInfo().getHeight();
            //str2+=channel.queryBlockchainInfo().getCurrentBlockHash();
            //channel.queryBlockByNumber(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return applic;
    }

    /**
     *
     * 测试用--链码调用方法
     * 不传参
     * 将固定值写入账本
     *
     */


    @RequestMapping("/chaincodeinvoke")
    public String chaincodeInvoke(){
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            TransactionProposalRequest request = fabClient.getInstance().newTransactionProposalRequest();


            ChaincodeID ccid = ChaincodeID.newBuilder().setName(Config.CHAINCODE_1_NAME).build();
            request.setChaincodeID(ccid);
            request.setFcn("initApplicationRecord");
            String[] arguments = { "dataset0","applicant1","noticer1","noticetime1","confirmor1","confirmtime1","omicsoriginalresultprovider1","omicsoriginalapplicationreceivedtime1","omicsanalysisresultprovider1","omicsapplicationreceivedtime1","phenotypicdataprovider1","phenotypicapplicationreceivedtime1","datadeliverytime1","datadeliverymethod1","deliverer1","deliverercontactinformation1"};
            arguments[0]="dataset"+NUM_OF_APLLICATION;
            request.setArgs(arguments);
            request.setProposalWaitTime(1000);

            Map<String, byte[]> tm2 = new HashMap<>();
            tm2.put("HyperLedgerFabric", "TransactionProposalRequest:JavaSDK".getBytes(UTF_8));
            tm2.put("method", "TransactionProposalRequest".getBytes(UTF_8));
            tm2.put("result", ":)".getBytes(UTF_8));
            tm2.put(EXPECTED_EVENT_NAME, EXPECTED_EVENT_DATA);
            request.setTransientMap(tm2);
            Collection<ProposalResponse> responses = channelClient.sendTransactionProposal(request);
            for (ProposalResponse res: responses) {
                ChaincodeResponse.Status status = res.getStatus();
                Logger.getLogger(InvokeChaincode.class.getName()).log(Level.INFO,"Invoked initApplicationRecord on "+Config.CHAINCODE_1_NAME + ". Status - " + status);
            }
            NUM_OF_APLLICATION++;


            //channelClient.getChannel();
            str_chaincode_invoke=channel.isInitialized()+"";
            //channel.queryBlockchainInfo();
            //channel.queryBlockByNumber(1);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (InvalidArgumentException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (CryptoException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ProposalException e) {
            e.printStackTrace();
        } catch (TransactionException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!str_chaincode_invoke.toString().equals("调用失败")) {
            return "success";
        }else{
            return "error";
        }
    }


    /*
    * 使用传参方式进行链码调用
    *
    * 将申请记录写入账本
    *
    *
    * */

    @RequestMapping("/chaincodeinvokebyparam")
    @ResponseBody

    public String chaincodeInvokebyparam(
                                         @RequestParam(name="Dataset")String Dataset,
                                         @RequestParam(name="Applicant")String Applicant,
                                         @RequestParam(name="Noticer")String Noticer,
                                         @RequestParam(name="Noticetime")String Noticetime,
                                         @RequestParam(name="Confirmor")String Confirmor,
                                         @RequestParam(name="Confirmtime")String Confirmtime,
                                         @RequestParam(name="Omicsoriginalresultprovider")String Omicsoriginalresultprovider,
                                         @RequestParam(name="Omicsoriginalapplicationreceivedtime")String Omicsoriginalapplicationreceivedtime,
                                         @RequestParam(name="Omicsanalysisresultprovider")String Omicsanalysisresultprovider,
                                         @RequestParam(name="Omicsapplicationreceivedtime")String Omicsapplicationreceivedtime,
                                         @RequestParam(name="Phenotypicdataprovider")String Phenotypicdataprovider,
                                         @RequestParam(name="Phenotypicapplicationreceivedtime")String Phenotypicapplicationreceivedtime,
                                         @RequestParam(name="Datadeliverytime")String Datadeliverytime,
                                         @RequestParam(name="Datadeliverymethod")String Datadeliverymethod,
                                         @RequestParam(name="Deliverer")String Deliverer,
                                         @RequestParam(name="Deliverercontactinformation")String Deliverercontactinformation){
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            TransactionProposalRequest request = fabClient.getInstance().newTransactionProposalRequest();


            ChaincodeID ccid = ChaincodeID.newBuilder().setName(Config.CHAINCODE_1_NAME).build();
            request.setChaincodeID(ccid);
            request.setFcn("initApplicationRecord");
            String[] arguments = { "dataset1","applicant1","noticer1","noticetime1","confirmor1","confirmtime1","omicsoriginalresultprovider1","omicsoriginalapplicationreceivedtime1","omicsanalysisresultprovider1","omicsapplicationreceivedtime1","phenotypicdataprovider1","phenotypicapplicationreceivedtime1","datadeliverytime1","datadeliverymethod1","deliverer1","deliverercontactinformation1"};

            //对参数进行赋值
            arguments[0]=Dataset;
            arguments[1]=Applicant;
            arguments[2]=Noticer;
            arguments[3]=""+Noticetime;
            arguments[4]=Confirmor;
            arguments[5]=""+Confirmtime;
            arguments[6]=Omicsoriginalresultprovider;
            arguments[7]=""+Omicsoriginalapplicationreceivedtime;
            arguments[8]=Omicsanalysisresultprovider;
            arguments[9]=""+Omicsapplicationreceivedtime;
            arguments[10]=Phenotypicdataprovider;
            arguments[11]=""+Phenotypicapplicationreceivedtime;
            arguments[12]=""+Datadeliverytime;
            arguments[13]=Datadeliverymethod;
            NUM_OF_APLLICATION++;
            //数据交付人默认是申请人
            if(Deliverer==null){
                arguments[14]=Applicant;
            }
            arguments[14]=Deliverer;
            arguments[15]=Deliverercontactinformation;

            for (String i:arguments) {
                System.out.println(i);
            }

            request.setArgs(arguments);
            request.setProposalWaitTime(1000);

            Map<String, byte[]> tm2 = new HashMap<>();
            tm2.put("HyperLedgerFabric", "TransactionProposalRequest:JavaSDK".getBytes(UTF_8));
            tm2.put("method", "TransactionProposalRequest".getBytes(UTF_8));
            tm2.put("result", ":)".getBytes(UTF_8));
            tm2.put(EXPECTED_EVENT_NAME, EXPECTED_EVENT_DATA);
            request.setTransientMap(tm2);
            str_chaincode_invoke="调用成功"+"\n";
            Collection<ProposalResponse> responses = channelClient.sendTransactionProposal(request);
            for (ProposalResponse res: responses) {
                ChaincodeResponse.Status status = res.getStatus();
                str_chaincode_invoke+=""+"Invoked initApplicationRecord on "+Config.CHAINCODE_1_NAME + ". Status - " + status+"\n";
                Logger.getLogger(InvokeChaincode.class.getName()).log(Level.INFO,"Invoked InitApplicationRecord on "+Config.CHAINCODE_1_NAME + ". Status - " + status);
            }




            //channelClient.getChannel();
            //str_chaincode_invoke=channel.isInitialized()+"";
            //channel.queryBlockchainInfo();
            //channel.queryBlockByNumber(1);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (InvalidArgumentException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (CryptoException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ProposalException e) {
            e.printStackTrace();
        } catch (TransactionException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!str_chaincode_invoke.toString().equals("调用失败")) {
            return str_chaincode_invoke;
        }else{
            return "链码调用失败";
        }
    }


    /*
    * 链码调用查询
    *
    * */


    @RequestMapping("/chaincodeinvokequery")
    public ModelAndView chaincodeInvokeQuery(){
        ModelAndView mv = new ModelAndView();
        mv.addObject("id",1);
        mv.addObject("name","dongguo");
        mv.setViewName("success");
        return  mv;

    }


    @RequestMapping("/getapplicationrecord")
    public ModelAndView getapplicationrecord(){
        ModelAndView mv = new ModelAndView();
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();
            String[] args1 = {"dataset0"};
            String[] args2 = {"applicant1"};
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord by key:dataset - " + args1[0]);

            Collection<ProposalResponse>  responses1Query = channelClient.queryByChainCode("odschaincode", "readApplicationRecord", args1);
            for (ProposalResponse pres : responses1Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }

            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord by applicant - "+ args2[0] );
            Collection<ProposalResponse>  responses2Query = channelClient.queryByChainCode("odschaincode", "queryApplicationRecordsByApplicant",args2);
            for (ProposalResponse pres : responses2Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                //JSONObject jsonObject=new JSONObject(pres.getChaincodeActionResponsePayload());
                //System.out.println(JSONObject.fromObject(stringResponse).getString("APPLICATIONRECORD0"));
                System.out.println(JSONObject.fromObject(stringResponse).getString("dataset"));
                mv.addObject("Dataset",JSONObject.fromObject(stringResponse).getString("dataset"));

                mv.addObject("Applicant",JSONObject.fromObject(stringResponse).getString("applicant"));
                mv.addObject("Noticer",JSONObject.fromObject(stringResponse).getString("noticer"));
                mv.addObject("Noticetime",JSONObject.fromObject(stringResponse).getString("noticetime"));
                mv.addObject("Confirmor",JSONObject.fromObject(stringResponse).getString("confirmor"));
                mv.addObject("Confirmtime",JSONObject.fromObject(stringResponse).getString("confirmtime"));
                mv.addObject("Omicsoriginalresultprovider",JSONObject.fromObject(stringResponse).getString("omicsoriginalresultprovider"));
                mv.addObject("Omicsoriginalapplicationreceivedtime",JSONObject.fromObject(stringResponse).getString("omicsoriginalapplicationreceivedtime"));
                mv.addObject("Omicsanalysisresultprovider",JSONObject.fromObject(stringResponse).getString("omicsanalysisresultprovider"));
                mv.addObject("Omicsapplicationreceivedtime",JSONObject.fromObject(stringResponse).getString("omicsapplicationreceivedtime"));
                mv.addObject("Phenotypicdataprovider",JSONObject.fromObject(stringResponse).getString("phenotypicdataprovider"));
                mv.addObject("Phenotypicapplicationreceivedtime",JSONObject.fromObject(stringResponse).getString("phenotypicapplicationreceivedtime"));
                mv.addObject("Datadeliverytime",JSONObject.fromObject(stringResponse).getString("datadeliverytime"));
                mv.addObject("Datadeliverymethod",JSONObject.fromObject(stringResponse).getString("datadeliverymethod"));
                mv.addObject("Deliverer",JSONObject.fromObject(stringResponse).getString("deliverer"));
                mv.addObject("Deliverercontactinformation",JSONObject.fromObject(stringResponse).getString("deliverercontactinformation"));

                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse+"\n");
            }

            //mv.addObject("applicationrecord",stringResponse)


            mv.setViewName("applicationrecord");

            //str1="区块长度:"+channel.queryBlockchainInfo().getHeight();
            //str2+=channel.queryBlockchainInfo().getCurrentBlockHash();
            //channel.queryBlockByNumber(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mv;
    }


    //根据某个参数查询查询

    @RequestMapping("/getapplicationrecordbyparam")
    @ResponseBody
    public String getapplicationrecordbyparam(@RequestParam(name="param") String str){
        String str_return = "";
        //ModelAndView mv = new ModelAndView();
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();
            String[] args={""};
            args[0]="{\"selector\":{\"noticer\":\""+str+"\"}}";
            String[] args1 = {""};
            args1[0]="{\"selector\":{\"datadeliverytime\":\"datadeliverytime1\"}}";
            String[] args2 = {""};
            args2[0]="{\"selector\":{\"datadeliverymethod\":\"datadeliverymethod1\"}}";

            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord - " + args[0]);

            Collection<ProposalResponse>  responsesQuery = channelClient.queryByChainCode("odschaincode", "queryApplicationRecords", args);
            for (ProposalResponse pres : responsesQuery) {

                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                if(stringResponse==null){
                    System.out.println("查询结果为空");
                }
                str+=""+stringResponse;
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord - " + args1[0]);

            Collection<ProposalResponse>  responses1Query = channelClient.queryByChainCode("odschaincode", "queryApplicationRecords", args1);
            for (ProposalResponse pres : responses1Query) {

                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                if(stringResponse==null){
                    System.out.println("查询结果为空");
                }
                str+=""+stringResponse;
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse);
            }

            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord  - "+ args2[0] );
            Collection<ProposalResponse>  responses2Query = channelClient.queryByChainCode("odschaincode", "queryApplicationRecords",args2);
            for (ProposalResponse pres : responses2Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                if(stringResponse==null){
                    System.out.println("查询结果为空");
                }
                //JSONObject jsonObject=new JSONObject(pres.getChaincodeActionResponsePayload());
                //System.out.println(JSONObject.fromObject(stringResponse).getString("APPLICATIONRECORD0"));
                System.out.println(JSONObject.fromObject(stringResponse).getString("申请人"));
                str+=""+stringResponse;

                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse+"\n");
            }

            //mv.addObject("applicationrecord",stringResponse)



            //str1="区块长度:"+channel.queryBlockchainInfo().getHeight();
            //str2+=channel.queryBlockchainInfo().getCurrentBlockHash();
            //channel.queryBlockByNumber(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str_return;
    }





    @RequestMapping("/puttest")
    @ResponseBody
    public  List<applicationrecord> puttest(){
        ModelAndView mv =new ModelAndView();
        List<applicationrecord> applic=new ArrayList<applicationrecord>();
        applicationrecord app=new applicationrecord("APPLICATION0","aad","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd");
        applicationrecord app1=new applicationrecord("APPLICATION1","aad","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd","pdoapsd");
        applic.add(app);
        applic.add(app1);
        //mv.addObject(applic);
        //mv.setViewName("applicationtable");
        return applic;
    }




}
