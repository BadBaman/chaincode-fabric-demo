package org.example.java.util.Crypto;

//import static org.example.java.util.Crypto.Sha256Crypto.byte2Hex;
import org.hyperledger.fabric.sdk.User;

import static org.example.java.util.Crypto.Sha256Crypto.getSHA256;

public class CryptoTest {
    public static void main(String[] args) {
        String URL="www.baidu.com";
        String URL_Crypto=null;





        System.out.println();

    }
}
