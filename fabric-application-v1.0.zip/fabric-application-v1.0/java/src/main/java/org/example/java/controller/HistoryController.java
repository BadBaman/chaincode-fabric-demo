package org.example.java.controller;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.example.java.chaincode.invocation.QueryChaincode;
import org.example.java.client.CAClient;
import org.example.java.client.ChannelClient;
import org.example.java.client.FabricClient;
import org.example.java.config.Config;
import org.example.java.entity.applicationrecord;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HistoryController {

    @RequestMapping("/queryapplicationrecordhistory")
    @ResponseBody
    public List<applicationrecord> queryallapplicationrecordhistory(
            @RequestParam(name="dataset") String Dataset
    ){
        //ModelAndView mv=new ModelAndView();
        List<applicationrecord> applic=new ArrayList<applicationrecord>();
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);
            String[] args = {Dataset};
            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();

            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for applicationRecord history...");
            Collection<ProposalResponse> responsesQuery = channelClient.queryByChainCode("odschaincode", "getHistoryForApplicationRecord", args);

            for (ProposalResponse pres : responsesQuery) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
//                for(int i = 0; i< JSONArray.fromObject(stringResponse).size(); i++){
//                    System.out.println(JSONArray.fromObject(stringResponse).get(i));
//
//                    applicationrecord app =new applicationrecord();
//                    JSONObject jsonObject=JSONObject.fromObject(JSONObject.fromObject(JSONArray.fromObject(stringResponse).get(i)).getString("Record"));
//                    app.setDataset(JSONObject.fromObject(JSONArray.fromObject(stringResponse).get(i)).getString("Key"));
//
//                    app.setApplicant(jsonObject.getString("applicant"));
//                    app.setNoticer(jsonObject.getString("noticer"));
//                    app.setNoticetime(jsonObject.getString("noticetime"));
//                    app.setConfirmor(jsonObject.getString("confirmor"));
//                    app.setConfirmtime(jsonObject.getString("confirmtime"));
////                    app.setOmicsoriginalresultprovider(jsonObject.getString("组学原始数据提供人"));
////                    app.setOmicsoriginalapplicationreceivedtime(jsonObject.getString("组学原始数据申请收到时间"));
////                    app.setOmicsanalysisresultprovider(jsonObject.getString("组学分析数据提供人"));
////                    app.setOmicsapplicationreceivedtime(jsonObject.getString("组学分析数据申请收到时间"));
////                    app.setPhenotypicdataprovider(jsonObject.getString("表型数据提供人"));
////                    app.setPhenotypicapplicationreceivedtime(jsonObject.getString("表型数据申请收到时间"));
////                    app.setDatadeliverytime(jsonObject.getString("数据交付时间"));
////                    app.setDatadeliverymethod(jsonObject.getString("数据交付方式"));
////                    app.setDeliverer(jsonObject.getString("数据交付人"));
////                    app.setDeliverercontactinformation(jsonObject.getString("联系方式"));
//                    applic.add(app) ;
//                }



                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, stringResponse+"\n");
            }


            //mv.setViewName("applicationtable");
            //Thread.sleep(10000);



            //str1="区块长度:"+channel.queryBlockchainInfo().getHeight();
            //str2+=channel.queryBlockchainInfo().getCurrentBlockHash();
            //channel.queryBlockByNumber(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return applic;
    }
}
