package org.example.java.controller;

import org.example.java.chaincode.invocation.QueryChaincode;
import org.example.java.client.CAClient;
import org.example.java.client.ChannelClient;
import org.example.java.client.FabricClient;
import org.example.java.config.Config;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Arrays;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.nio.charset.StandardCharsets.UTF_8;


/*
 * @author:likaiyuan
 *
 *
 * */

/*
* about blocks
*
*
* */

@Controller
public class BlockController {

    private static final byte[] EXPECTED_EVENT_DATA = "!".getBytes(UTF_8);
    private static final String EXPECTED_EVENT_NAME = "event";

    @RequestMapping("/chaincodequeryblockheight")
    @ResponseBody
    public long chaincodequeryblockheight(){
        System.out.println(QueryChaincode.querychaincode());
        return QueryChaincode.querychaincode();
    }

    @RequestMapping("/chaincodequeryusernum")
    @ResponseBody
    public long chaincodequeryusernum(){
        System.out.println(QueryChaincode.querychaincode());
        return QueryChaincode.querychaincode();
    }

    /*
    * 通过数字
    * 查询区块
    *
    * */

    @RequestMapping("/queryblockbynum")
    public String queryblockbynum(){
        try {
            Util.cleanUp();
            String caUrl = Config.CA_ORG1_URL;
            CAClient caClient = new CAClient(caUrl, null);
            // Enroll Admin to Org1MSP
            UserContext adminUserContext = new UserContext();
            adminUserContext.setName(Config.ADMIN);
            adminUserContext.setAffiliation(Config.ORG1);
            adminUserContext.setMspId(Config.ORG1_MSP);
            caClient.setAdminUserContext(adminUserContext);
            adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

            FabricClient fabClient = new FabricClient(adminUserContext);

            ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
            Channel channel = channelClient.getChannel();
            Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01", "grpc://localhost:7053");
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            channel.addPeer(peer);
            channel.addEventHub(eventHub);
            channel.addOrderer(orderer);
            channel.initialize();


            String[] args1 = {"APPLICATIONRECORD0"};
            String[] args2 = {""};
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for a applicationRecord - " + args1[0]);

            Collection<ProposalResponse>  responses1Query = channelClient.queryByChainCode("odschaincode", "queryApplicationRecord", args1);
            for (ProposalResponse pres : responses1Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, String.valueOf(channel.queryBlockchainInfo()));
            }
            Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, "Querying for all  - " );
            Collection<ProposalResponse>  responses2Query = channelClient.queryByChainCode("odschaincode", "queryApplicationRecord",args2);
            for (ProposalResponse pres : responses2Query) {
                String stringResponse = new String(pres.getChaincodeActionResponsePayload());
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, String.valueOf(channel.queryBlockchainInfo()));
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, String.valueOf(channel.queryBlockchainInfo().getHeight()));
                Logger.getLogger(QueryChaincode.class.getName()).log(Level.INFO, Arrays.toString(channel.queryBlockchainInfo().getCurrentBlockHash()));
            }
            //str1="区块长度:"+channel.queryBlockchainInfo().getHeight();
            //str2+=channel.queryBlockchainInfo().getCurrentBlockHash();
            //channel.queryBlockByNumber(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "success";
    }

}
