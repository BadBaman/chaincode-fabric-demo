package org.example.java.controller;

import org.example.java.client.ChannelClient;
import org.example.java.client.FabricClient;
import org.example.java.config.Config;
import org.example.java.network.DeployInstantiateChaincode;
import org.example.java.user.UserContext;
import org.example.java.util.Util;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
 * @author:likaiyuan
 *
 *
 * */


@Controller
public class ChaincodeInstantiateDeployController {

    private String str_chaincode_instantiate="实例化失败";


    /*
    * 智能合约实例化
    *
    * 将config文件中固定的
    * 配置信息进行读取
    * */

    @RequestMapping("/chaincodeinstantiate")
    @ResponseBody
    public String chaincodeInstantiate(){
        try {
            CryptoSuite cryptoSuite = CryptoSuite.Factory.getCryptoSuite();

            UserContext org1Admin = new UserContext();
            File pkFolder1 = new File(Config.ORG1_USR_ADMIN_PK);
            File[] pkFiles1 = pkFolder1.listFiles();
            File certFolder = new File(Config.ORG1_USR_ADMIN_CERT);
            File[] certFiles = certFolder.listFiles();
            Enrollment enrollOrg1Admin = Util.getEnrollment(Config.ORG1_USR_ADMIN_PK, pkFiles1[0].getName(),
                    Config.ORG1_USR_ADMIN_CERT, certFiles[0].getName());
            org1Admin.setEnrollment(enrollOrg1Admin);
            org1Admin.setMspId("Org1MSP");
            org1Admin.setName("admin");

            UserContext org2Admin = new UserContext();
            File pkFolder2 = new File(Config.ORG2_USR_ADMIN_PK);
            File[] pkFiles2 = pkFolder2.listFiles();
            File certFolder2 = new File(Config.ORG2_USR_ADMIN_CERT);
            File[] certFiles2 = certFolder2.listFiles();
            Enrollment enrollOrg2Admin = Util.getEnrollment(Config.ORG2_USR_ADMIN_PK, pkFiles2[0].getName(),
                    Config.ORG2_USR_ADMIN_CERT, certFiles2[0].getName());
            org2Admin.setEnrollment(enrollOrg2Admin);
            org2Admin.setMspId(Config.ORG2_MSP);
            org2Admin.setName(Config.ADMIN);

            FabricClient fabClient = new FabricClient(org1Admin);

            Channel mychannel = fabClient.getInstance().newChannel(Config.CHANNEL_NAME);
            Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
            Peer peer0_org1 = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
            Peer peer1_org1 = fabClient.getInstance().newPeer(Config.ORG1_PEER_1, Config.ORG1_PEER_1_URL);
            Peer peer0_org2 = fabClient.getInstance().newPeer(Config.ORG2_PEER_0, Config.ORG2_PEER_0_URL);
            Peer peer1_org2 = fabClient.getInstance().newPeer(Config.ORG2_PEER_1, Config.ORG2_PEER_1_URL);
            mychannel.addOrderer(orderer);
            mychannel.addPeer(peer0_org1);
            mychannel.addPeer(peer1_org1);
            mychannel.addPeer(peer0_org2);
            mychannel.addPeer(peer1_org2);
            mychannel.initialize();

            List<Peer> org1Peers = new ArrayList<Peer>();
            org1Peers.add(peer0_org1);
            org1Peers.add(peer1_org1);

            List<Peer> org2Peers = new ArrayList<Peer>();
            org2Peers.add(peer0_org2);
            org2Peers.add(peer1_org2);

            Collection<ProposalResponse> response = fabClient.deployChainCode(Config.CHAINCODE_1_NAME,
                    Config.CHAINCODE_1_PATH, Config.CHAINCODE_ROOT_DIR, TransactionRequest.Type.GO_LANG.toString(),
                    Config.CHAINCODE_1_VERSION, org1Peers);

            if(response!=null){
                str_chaincode_instantiate="实例化成功"+"\n";
            }
            for (ProposalResponse res : response) {
                str_chaincode_instantiate+=""+Config.CHAINCODE_1_NAME + "- Chain code deployment " + res.getStatus()+"\n";
                Logger.getLogger(DeployInstantiateChaincode.class.getName()).log(Level.INFO,
                        Config.CHAINCODE_1_NAME + "- Chain code deployment " + res.getStatus());
            }

            fabClient.getInstance().setUserContext(org2Admin);

            response = fabClient.deployChainCode(Config.CHAINCODE_1_NAME,
                    Config.CHAINCODE_1_PATH, Config.CHAINCODE_ROOT_DIR, TransactionRequest.Type.GO_LANG.toString(),
                    Config.CHAINCODE_1_VERSION, org2Peers);


            for (ProposalResponse res : response) {
                str_chaincode_instantiate+=""+Config.CHAINCODE_1_NAME + "- Chain code deployment " + res.getStatus()+"\n";
                Logger.getLogger(DeployInstantiateChaincode.class.getName()).log(Level.INFO,
                        Config.CHAINCODE_1_NAME + "- Chain code deployment " + res.getStatus());
            }

            ChannelClient channelClient = new ChannelClient(mychannel.getName(), mychannel, fabClient);

            String[] arguments = { "" };
            response = channelClient.instantiateChainCode(Config.CHAINCODE_1_NAME, Config.CHAINCODE_1_VERSION,
                    Config.CHAINCODE_1_PATH, TransactionRequest.Type.GO_LANG.toString(), "init", arguments, null);

            for (ProposalResponse res : response) {
                str_chaincode_instantiate+=""+Config.CHAINCODE_1_NAME + "- Chain code instantiation " + res.getStatus()+"\n";
                Logger.getLogger(DeployInstantiateChaincode.class.getName()).log(Level.INFO,
                        Config.CHAINCODE_1_NAME + "- Chain code instantiation " + res.getStatus());
            }



        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!str_chaincode_instantiate.toString().equals("实例化失败")){
            return str_chaincode_instantiate;
        }else{
            return "实例化失败";
        }

    }
}
